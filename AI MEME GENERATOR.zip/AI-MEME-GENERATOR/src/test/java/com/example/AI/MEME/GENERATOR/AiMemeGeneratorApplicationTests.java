package com.example.AI.MEME.GENERATOR;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiMemeGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
