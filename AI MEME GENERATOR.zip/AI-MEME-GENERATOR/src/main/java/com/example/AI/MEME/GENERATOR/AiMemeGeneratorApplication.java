package com.example.AI.MEME.GENERATOR;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiMemeGeneratorApplication {

	public static void main(String[] args) {
		SpringApplication.run(AiMemeGeneratorApplication.class, args);
	}

}
